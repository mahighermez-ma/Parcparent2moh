package pro.kidsgaurd;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class UnblockedAppItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(pro.kidsgaurd.R.layout.activity_unblockedappitem);
    }
}
